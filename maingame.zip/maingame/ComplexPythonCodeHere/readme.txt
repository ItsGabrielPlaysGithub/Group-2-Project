Put "gameplaymultiplayer.py" to the ping pong directory. (which it includes images and sounds)

Use any python IDE then run "gameplaymultiplayer.py"... If you use exe then you cant see the update :)